
# Frequency Zero Capture System

This kit includes:
- Quick user guide
- Mobile-optimized placeholder text
- Tag definitions and color codes
- Success message
- Airtable schema overview

---

## 📘 Quick User Guide
You're tuned to Frequency Zero.
This form helps you hold what flickers before it vanishes.

### 🟣 Captured Moment
a flicker, a fragment—what just appeared?

### 🌀 Initial Thought
why did this pulse hit? what echo does it carry?

### 🔗 Linked Artifact (optional)
what thread does this tug? name the shape

### 🎭 Frequency
Which self was active?
- 🟣 Echo = Receiving
- 🟠 Mystique = Shaping

### 🧷 Tags
- 💚 #artifact-seed: wants to grow
- 💛 #to-process: unclear yet
- 💗 #memory: emotionally anchored
- 🟣 #signal: raw, incoming

### ✅ Success Message
signal captured. it’s now safe in the archive.

### 🧭 Daily Rhythm
1–3x max capture.
Weekly review suggested.

---

## 📱 Mobile Optimizations

### Placeholder Text
- Captured Moment: `a flicker, a fragment—what just appeared?`
- Initial Thought: `why did this pulse hit? what echo does it carry?`
- Linked Artifact: `what thread does this tug? name the shape`

### Footer Suggestion
`🛸 signal archived. drift continues.`

---

## Airtable Schema Overview

| Field               | Type           | Notes                                 |
|--------------------|----------------|---------------------------------------|
| Captured Moment     | Primary Text   | Core signal                           |
| Tag                 | Single select  | Color-coded emotional texture         |
| Mode                | Single select  | Echo / Mystique                       |
| Initial Thought     | Long text      | Stream of response                    |
| Linked Artifact     | Text (optional)| Connects to existing work             |
| Created On          | Created Time   | For sorting / filtering               |
| Today?              | Formula        | IF(IS_SAME({Created On}, TODAY(), 'day'), "Yes", "") |

---

Built in alignment with Signal Lost and Frequency Zero.
